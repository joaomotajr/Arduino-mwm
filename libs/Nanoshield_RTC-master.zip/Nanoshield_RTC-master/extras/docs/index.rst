.. toctree::
   :maxdepth: 2

.. include:: ../../README.rst
   :end-before: ----

Class Documentation
===================

.. doxygenclass:: DS1307
   :project: Nanoshield_RTC
   :members:

.. doxygenclass:: DS3231
   :project: DS3231
   :members:

.. doxygenclass:: Nanoshield_RTC
   :project: Nanoshield_RTC
   :members:

----

This documentation was built using ArduinoDocs_.

.. _ArduinoDocs: http://arduinodocs.readthedocs.org
